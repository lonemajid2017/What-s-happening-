# What's Happening

A GitHub-ready global news dashboard for generating original X posts from high-impact news.

Focus:
- USA and Trump
- Finance and markets
- Crypto
- Middle East
- India
- World and geopolitics
- AI and technology

## APIs

Required GitHub Secrets:
- GEMINI_API_KEY
- NEWS_API_KEY
- GNEWS_API_KEY
- GUARDIAN_API_KEY
- COINGECKO_API_KEY

Never put secret values in source files.

## How it works

NewsAPI + GNews + Guardian + CoinGecko
-> normalize
-> deduplicate
-> rank
-> Gemini
-> original X post
-> source attribution
-> saved in data/posts.json

The app does not use the X API and never posts automatically to X.

## Important source rule

A source is marked verified only when it is in the trusted source registry. The app does not claim that Gemini verified a source.

## GitHub Actions

The workflow checks for new stories every 15 minutes and commits updated JSON data.

For browser notifications, keep the dashboard open and grant notification permission. A future hosted backend can add true background push notifications when the browser is closed.

## Local run

```bash
npm install
cp .env.example .env
npm start
```

Open http://localhost:3000

For a local monitor:

```bash
npm run fetch-news
```

## Limitations

Some publishers do not offer free public APIs. The first version therefore uses the configured APIs and their returned publisher/source metadata. It does not bypass paywalls, authentication, robots restrictions or licensing controls.

For more publisher coverage, add official RSS/public feeds only when their terms permit automated use.
