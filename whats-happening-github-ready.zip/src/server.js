import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { collectNews } from "./news.js";
import { generateReplies, generatePosts } from "./gemini.js";
import { addPosts, addStories, readJson } from "./storage.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.resolve(__dirname, "../public")));

app.get("/api/news", async (_req, res) => {
  res.json(await readJson("news.json", { updatedAt: null, stories: [] }));
});

app.get("/api/posts", async (_req, res) => {
  res.json(await readJson("posts.json", { updatedAt: null, posts: [] }));
});

app.get("/api/health", async (_req, res) => {
  res.json({
    ok: true,
    gemini: Boolean(process.env.GEMINI_API_KEY),
    newsApi: Boolean(process.env.NEWS_API_KEY),
    gnews: Boolean(process.env.GNEWS_API_KEY),
    guardian: Boolean(process.env.GUARDIAN_API_KEY),
    coingecko: Boolean(process.env.COINGECKO_API_KEY)
  });
});

app.post("/api/refresh", async (_req, res) => {
  try {
    const stories = await collectNews();
    await addStories(stories);
    const fresh = stories.filter((s) => s.importance >= 55).slice(0, 12);
    const generated = process.env.GEMINI_API_KEY ? await generatePosts(fresh) : [];
    const posts = generated.map((p) => {
      const story = fresh.find((s) => s.id === p.storyId);
      return {
        id: `${p.storyId}-${Date.now()}`,
        storyId: p.storyId,
        post: p.post,
        source: story?.sources?.join(", ") || story?.source || "Unknown",
        url: story?.url || "",
        category: story?.category || "World",
        importance: story?.importance || 0,
        createdAt: new Date().toISOString(),
        ready: true
      };
    });
    if (posts.length) await addPosts(posts);
    res.json({ stories, posts });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/replies", async (req, res) => {
  try {
    const text = String(req.body?.text || "").trim();
    if (!text) return res.status(400).json({ error: "Post text is required" });
    res.json({ replies: await generateReplies(text) });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get("*splat", (_req, res) => res.sendFile(path.resolve(__dirname, "../public/index.html")));

app.listen(PORT, () => console.log(`What's Happening running on port ${PORT}`));
