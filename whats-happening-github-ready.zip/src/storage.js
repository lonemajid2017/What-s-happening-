import fs from "node:fs/promises";
import path from "node:path";

const DATA = path.resolve("data");
await fs.mkdir(DATA, { recursive: true });

export async function readJson(file, fallback) {
  try {
    return JSON.parse(await fs.readFile(path.join(DATA, file), "utf8"));
  } catch {
    return fallback;
  }
}

export async function writeJson(file, value) {
  await fs.writeFile(
    path.join(DATA, file),
    JSON.stringify(value, null, 2),
    "utf8"
  );
}

export async function addStories(stories) {
  const current = await readJson("news.json", { updatedAt: null, stories: [] });
  const byId = new Map(current.stories.map((s) => [s.id, s]));
  for (const story of stories) byId.set(story.id, story);
  const merged = [...byId.values()]
    .sort((a, b) => new Date(b.publishedAt || 0) - new Date(a.publishedAt || 0))
    .slice(0, 300);
  await writeJson("news.json", { updatedAt: new Date().toISOString(), stories: merged });
  return merged;
}

export async function addPosts(posts) {
  const current = await readJson("posts.json", { updatedAt: null, posts: [] });
  const byId = new Map(current.posts.map((p) => [p.id, p]));
  for (const post of posts) byId.set(post.id, post);
  const merged = [...byId.values()].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 300);
  await writeJson("posts.json", { updatedAt: new Date().toISOString(), posts: merged });
  return merged;
}
