const UA = "Whats-Happening/1.0";

const TOPICS = {
  USA: ["United States", "Trump", "White House", "Federal Reserve", "Congress", "US economy", "US politics"],
  Finance: ["stocks", "markets", "Federal Reserve", "interest rates", "inflation", "banking", "economy"],
  Crypto: ["Bitcoin", "Ethereum", "crypto", "SEC crypto", "crypto ETF", "blockchain"],
  "Middle East": ["Israel", "Palestine", "Gaza", "Iran", "Lebanon", "Syria", "Middle East", "Saudi Arabia", "UAE"],
  India: ["India", "Modi", "RBI", "Indian economy", "Indian markets", "New Delhi"],
  World: ["Russia", "Ukraine", "China", "Europe", "Asia", "geopolitics", "United Nations"],
  "AI & Tech": ["OpenAI", "Google AI", "Microsoft", "Nvidia", "Apple", "Meta", "artificial intelligence", "technology"]
};

const TRUSTED = new Set([
  "Reuters", "Associated Press", "AP", "BBC News", "BBC", "Al Jazeera English",
  "The Telegraph", "TRT World", "Bloomberg", "The Washington Post", "The New York Times",
  "CNN", "CNBC", "Financial Times", "The Wall Street Journal", "Politico", "The Hill",
  "The Guardian", "Agence France-Presse", "AFP", "DW", "Euronews", "TASS",
  "The Hindu", "The Indian Express", "Hindustan Times", "ANI", "CoinDesk", "The Block"
]);

function cleanText(value = "") {
  return String(value).replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
}

function hash(text) {
  let h = 2166136261;
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16);
}

function categoryFor(text) {
  const lower = text.toLowerCase();
  for (const [category, words] of Object.entries(TOPICS)) {
    if (words.some((w) => lower.includes(w.toLowerCase()))) return category;
  }
  return "World";
}

function importanceFor(text, source, publishedAt) {
  const lower = text.toLowerCase();
  let score = 35;
  if (TRUSTED.has(source)) score += 20;
  const high = ["breaking", "trump", "fed", "war", "attack", "ceasefire", "iran", "israel", "bitcoin", "crash", "sanctions", "election", "rate cut", "rate hike"];
  score += high.filter((w) => lower.includes(w)).length * 5;
  const ageHours = Math.max(0, (Date.now() - new Date(publishedAt || Date.now()).getTime()) / 36e5);
  score -= Math.min(20, ageHours * 1.5);
  return Math.max(0, Math.min(100, Math.round(score)));
}

function normalize(item) {
  const title = cleanText(item.title);
  const description = cleanText(item.description || "");
  const source = cleanText(item.source || "Unknown");
  const url = item.url;
  const publishedAt = item.publishedAt || new Date().toISOString();
  if (!title || !url) return null;
  const base = `${title.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").slice(0, 220)}|${source.toLowerCase()}`;
  const id = hash(base);
  const text = `${title} ${description}`;
  return {
    id,
    title,
    description,
    source,
    url,
    publishedAt,
    category: categoryFor(text),
    importance: importanceFor(text, source, publishedAt),
    verified: TRUSTED.has(source),
    fetchedAt: new Date().toISOString()
  };
}

async function fetchJson(url, options = {}) {
  const response = await fetch(url, { ...options, headers: { "User-Agent": UA, ...(options.headers || {}) } });
  if (!response.ok) throw new Error(`${response.status} ${response.statusText}`);
  return response.json();
}

async function newsApi() {
  const key = process.env.NEWS_API_KEY;
  if (!key) return [];
  const q = encodeURIComponent(
    '"Trump" OR "Federal Reserve" OR crypto OR Bitcoin OR "Middle East" OR India OR geopolitics OR "artificial intelligence"'
  );
  const url = `https://newsapi.org/v2/everything?q=${q}&language=en&sortBy=publishedAt&pageSize=50&apiKey=${encodeURIComponent(key)}`;
  const data = await fetchJson(url);
  return (data.articles || []).map((a) => ({
    title: a.title, description: a.description, source: a.source?.name, url: a.url, publishedAt: a.publishedAt
  }));
}

async function gnews() {
  const key = process.env.GNEWS_API_KEY;
  if (!key) return [];
  const q = encodeURIComponent("Trump OR finance OR crypto OR Bitcoin OR Middle East OR India OR geopolitics OR AI");
  const url = `https://gnews.io/api/v4/search?q=${q}&lang=en&max=50&sortby=publishedAt&apikey=${encodeURIComponent(key)}`;
  const data = await fetchJson(url);
  return (data.articles || []).map((a) => ({
    title: a.title, description: a.description, source: a.source?.name, url: a.url, publishedAt: a.publishedAt
  }));
}

async function guardian() {
  const key = process.env.GUARDIAN_API_KEY;
  if (!key) return [];
  const q = encodeURIComponent("Trump OR finance OR crypto OR Bitcoin OR Middle East OR India OR geopolitics OR AI");
  const url = `https://content.guardianapis.com/search?q=${q}&order-by=newest&page-size=50&show-fields=trailText&api-key=${encodeURIComponent(key)}`;
  const data = await fetchJson(url);
  return (data.response?.results || []).map((a) => ({
    title: a.webTitle, description: a.fields?.trailText, source: "The Guardian", url: a.webUrl, publishedAt: a.webPublicationDate
  }));
}

async function coinGecko() {
  const key = process.env.COINGECKO_API_KEY;
  const headers = key ? { "x-cg-demo-api-key": key } : {};
  const url = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=10&page=1&sparkline=false";
  try {
    const data = await fetchJson(url, { headers });
    return data.slice(0, 10).map((c) => ({
      title: `${c.name} (${String(c.symbol).toUpperCase()}) is ${c.price_change_percentage_24h >= 3 ? "moving sharply higher" : c.price_change_percentage_24h <= -3 ? "moving sharply lower" : "moving"}: ${c.price_change_percentage_24h?.toFixed(2)}% in 24h`,
      description: `Market cap $${Number(c.market_cap || 0).toLocaleString("en-US")}. 24h volume $${Number(c.total_volume || 0).toLocaleString("en-US")}.`,
      source: "CoinGecko", url: `https://www.coingecko.com/en/coins/${c.id}`, publishedAt: new Date().toISOString()
    })).filter((x) => Math.abs(Number(x.title.match(/-?\d+\.\d+/)?.[0] || 0)) >= 3);
  } catch {
    return [];
  }
}

export async function collectNews() {
  const results = await Promise.allSettled([newsApi(), gnews(), guardian(), coinGecko()]);
  const raw = results.flatMap((r) => r.status === "fulfilled" ? r.value : []);
  const normalized = raw.map(normalize).filter(Boolean);

  const groups = new Map();
  for (const item of normalized) {
    const key = item.title.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").split(" ").filter(Boolean).slice(0, 12).join(" ");
    const existing = groups.get(key);
    if (!existing) groups.set(key, item);
    else {
      const sources = new Set([existing.source, item.source]);
      existing.sources = [...sources];
      if (item.importance > existing.importance) Object.assign(existing, item, { sources: [...sources] });
      else existing.sources = [...sources];
      existing.verified = existing.verified || item.verified;
    }
  }

  return [...groups.values()]
    .filter((x) => x.importance >= 45)
    .sort((a, b) => b.importance - a.importance || new Date(b.publishedAt) - new Date(a.publishedAt))
    .slice(0, 40);
}
