import crypto from "node:crypto";
import { collectNews } from "./news.js";
import { generatePosts } from "./gemini.js";
import { addPosts, addStories, readJson, writeJson } from "./storage.js";

const hash = (x) => crypto.createHash("sha256").update(x).digest("hex").slice(0, 24);

async function main() {
  const stories = await collectNews();
  const allStories = await addStories(stories);

  const seen = await readJson("seen.json", { items: [] });
  const seenSet = new Set(seen.items);
  const fresh = stories.filter((s) => !seenSet.has(s.id) && s.importance >= 55).slice(0, 12);

  let posts = [];
  if (fresh.length && process.env.GEMINI_API_KEY) {
    posts = await generatePosts(fresh);
    posts = posts.map((p) => {
      const story = fresh.find((s) => s.id === p.storyId);
      return {
        id: hash(`${p.storyId}|${p.post}`),
        storyId: p.storyId,
        post: p.post,
        source: story?.sources?.join(", ") || story?.source || "Unknown",
        url: story?.url || "",
        category: story?.category || "World",
        importance: story?.importance || 0,
        createdAt: new Date().toISOString(),
        ready: true
      };
    });
    await addPosts(posts);
  }

  for (const s of fresh) seenSet.add(s.id);
  const trimmed = [...seenSet].slice(-1000);
  await writeJson("seen.json", { items: trimmed });

  console.log(JSON.stringify({
    fetched: stories.length,
    fresh: fresh.length,
    generated: posts.length,
    updatedAt: new Date().toISOString()
  }, null, 2));

  if (!allStories.length) process.exitCode = 0;
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
