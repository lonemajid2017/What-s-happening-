const MODEL = "gemini-2.5-flash";

async function callGemini(contents) {
  const key = process.env.GEMINI_API_KEY;
  if (!key) throw new Error("GEMINI_API_KEY is not configured");
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${encodeURIComponent(key)}`;
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ contents: [{ parts: [{ text: contents }] }] })
  });
  if (!response.ok) throw new Error(`Gemini ${response.status}: ${await response.text()}`);
  const data = await response.json();
  return data.candidates?.[0]?.content?.parts?.map((p) => p.text || "").join("") || "";
}

function jsonFromText(text) {
  const match = text.match(/\[[\s\S]*\]/);
  if (!match) throw new Error("Gemini returned no JSON array");
  return JSON.parse(match[0]);
}

export async function generatePosts(stories) {
  if (!stories.length) return [];
  const payload = stories.slice(0, 20).map((s) => ({
    id: s.id, title: s.title, description: s.description, source: s.source,
    sources: s.sources || [s.source], url: s.url, category: s.category, publishedAt: s.publishedAt
  }));

  const prompt = `You are the editorial AI for an X account called What's Happening.
Create original, concise X posts only from the supplied verified news data.
Never invent facts. Never copy article wording. Never add unsupported claims.
Prioritize high-impact information. Do not create a post just to meet a quota.
Every post MUST contain a source attribution exactly using the supplied source name(s), such as "Source: Reuters" or "Sources: Reuters, AP".
Keep each post under 280 characters including the source attribution when possible.
Return ONLY valid JSON, an array of objects with: storyId, post.
News data:
${JSON.stringify(payload)}`;

  const result = jsonFromText(await callGemini(prompt));
  return result.map((x) => ({
    storyId: x.storyId,
    post: String(x.post || "").trim()
  })).filter((x) => x.storyId && x.post);
}

export async function generateReplies(text) {
  const prompt = `Generate exactly 3 useful X replies to this post.
Replies must be natural, specific and add value. Do not say "great post". Do not invent facts.
Return ONLY valid JSON as an array of objects with a "reply" field.
Post:
${text}`;
  const result = jsonFromText(await callGemini(prompt));
  return result.slice(0, 3).map((x) => ({ reply: String(x.reply || "").trim() })).filter((x) => x.reply);
}
